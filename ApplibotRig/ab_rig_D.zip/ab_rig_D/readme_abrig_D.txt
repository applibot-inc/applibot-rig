Applibot Rig

--------------------------------------------------------------------------

・対応Mayaバージョン：Maya2023以降となります
※それ以前のバージョンでの使用に際して、動作不良が起こる可能性があります。

・リグについて
今回のリグはエイビー、スイレンとは異なり弊社で使用しているモジュラーリギングシステム『general-rig』を適用しております。

・注意事項
工数の都合上、目と口だけ軽く動かせる状態で今回は留めております。
今後のアップデートにてフェイシャルの追加も検討しておりますが、練習用としてフェイシャルを独自に組んで頂く事は許容としております。

--------------------------------------------------------------------------

-Compatible with Maya 2023
*When using the Applibot Rig with earlier versions of Maya, there is a possibility of malfunction.


-Rig Controls
Unlike the AB and Suiren, this rig utilizes a modular rigging system called "general-rig".


-Notes
Due to the time and effort involved, facial expression control is limited to the eyes and mouth.
We are considering adding more expressions in future updates, but you are welcome to create your own expressions as practice.

--------------------------------------------------------------------------

 20240115
